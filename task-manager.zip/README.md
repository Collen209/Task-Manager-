# Task Manager ✅

A simple, browser-based task manager built with **HTML, CSS, and JavaScript**.  
This project shows clean code structure, user interaction, and responsive design.

---

## Features
- Add new tasks
- Mark tasks as completed (click on them)
- Delete tasks with a single button
- Lightweight, no setup required — just open in your browser

---

## Demo
![screenshot](screenshot.png)  
*(Add your own screenshot here once you run the app.)*

---

## How to Run
1. Clone or download this repository.  
2. Open `index.html` in any web browser.  
3. Start adding tasks!

---

## Why this project?
- Demonstrates **core web skills**: HTML structure, CSS styling, and JavaScript logic.  
- Clean, readable code with comments.  
- Practical: anyone can use it immediately.  

---

## Next Steps (if you want to expand)
- Save tasks in **LocalStorage** so they persist after refreshing.  
- Add **categories** or **deadlines**.  
- Polish UI with animations.  

---

Made by Collen Khumbulani Kumalo ✌🏽
