// Grab elements
const taskInput = document.getElementById("task");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");

// Add task when button clicked
addBtn.addEventListener("click", addTask);

// Allow pressing "Enter" to add task
taskInput.addEventListener("keypress", function(e) {
  if (e.key === "Enter") addTask();
});

function addTask() {
  const taskText = taskInput.value.trim();

  if (taskText === "") {
    alert("Please type something!");
    return;
  }

  // Create list item
  const li = document.createElement("li");

  // Task text
  const span = document.createElement("span");
  span.textContent = taskText;
  li.appendChild(span);

  // Mark complete on click
  span.addEventListener("click", () => {
    li.classList.toggle("completed");
  });

  // Delete button
  const delBtn = document.createElement("button");
  delBtn.textContent = "X";
  delBtn.style.background = "#dc3545";
  delBtn.style.color = "white";
  delBtn.style.border = "none";
  delBtn.style.padding = "5px 10px";
  delBtn.style.borderRadius = "6px";
  delBtn.style.cursor = "pointer";

  delBtn.addEventListener("click", () => {
    taskList.removeChild(li);
  });

  li.appendChild(delBtn);

  // Add task to list
  taskList.appendChild(li);

  // Clear input
  taskInput.value = "";
}